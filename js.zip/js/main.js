
$(document).ready(function () {

    // owl-crousel for blog
    $('.owl-carousel').owlCarousel();
    nav:true;
    

});